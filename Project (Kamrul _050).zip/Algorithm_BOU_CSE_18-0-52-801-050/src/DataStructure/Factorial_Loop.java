package DataStructure;

public class Factorial_Loop {

    public void factorial(int n) {
        int fact = 1;

        for (int i = 1; i <= n; i++) 
        {
            fact = fact * i;
        }
        System.out.println("The Factotial Value of "+n+" is\n"+fact);
    }
}
