/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataStructure;

import java.util.LinkedList;
import java.util.Scanner;

/**
 *
 * @author Imran
 *
 * //generic class
 */
public class Linked {

    LinkedList<String> ll = new LinkedList<String>();
    /* public void linked_display() {
    ll.add("Imran");
    ll.add("1234");
    ll.add("CA class");
    
        System.out.println(ll);
        ll.remove("Imran");
                System.out.println(ll);
}
} */

   
    Scanner sc = new Scanner(System.in);

    public void linked_display() {
        while (true) {
            System.out.println("Choose one operation: \nl. Add element\n2. Remove element\n3.display LinkedList\n4. Exit operation");
        
        int x = sc.nextInt();
        switch (x) {
            case 1:
                System.out.println("Type your element");
                String y = sc.next();
                
                ll.add(y);
                break;
            case 2:
                
                ll.remove();
                break;
            case 3:
                System.out.println(ll);
                break;
            default:
                System.out.println("Invalid choice");
        }
    }
    }
}