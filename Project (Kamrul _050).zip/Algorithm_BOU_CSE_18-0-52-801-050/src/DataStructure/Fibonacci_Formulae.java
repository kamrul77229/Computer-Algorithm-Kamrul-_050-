
package DataStructure;

public class Fibonacci_Formulae {

    static int fib(int n) {
        double phi = (1 + Math.sqrt(5)) / 2;                     //Fn = {[(√5 + 1)/2] ^ n} / √5
        return (int) Math.round(Math.pow(phi, n)/ Math.sqrt(5));
    }
}
