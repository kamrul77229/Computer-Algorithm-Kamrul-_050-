/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Graph;

import java.util.*;
import java.lang.*;
import java.io.*;
/**
 *
 * @author Imran
 */
public class ActivitySelectionProblem {
    // The following implementation assumes that the activities
// are already sorted according to their finish time




	// Prints a maximum set of activities that can be done by a single
	// person, one at a time.
	// n --> Total number of activities
	// s[] --> An array that contains start time of all activities
	// f[] --> An array that contains finish time of all activities
	public static void printMaxActivities(int s[], int f[], int n)
	{
	int i, j;
	
	System.out.print("Following activities are selected : n");
	
	// The first activity always gets selected
	i = 0;
	System.out.print(i+" ");
	
	// Consider rest of the activities
	for (j = 1; j < n; j++)
	{
		// If this activity has start time greater than or
		// equal to the finish time of previously selected
		// activity, then select it
		if (s[j] >= f[i])
		{
			System.out.print(j+" ");
			i = j;
		}
	}
	}
        

	// driver program to test above function
	public static void main(String[] args)
	{
	int s[] = {1, 3, 0, 5, 8, 5};
	int f[] = {2, 4, 6, 7, 9, 9};
	int n = s.length;
		
	printMaxActivities(s, f, n);
	}
}

////////////////////////////////////////////////////////////////////////
// Java program for activity selection problem
// when input activities may not be sorted.
//import java.io.*;
//import java.util.*;
// 
//// A job has a start time, finish time and profit.
//class Activity
//{
//  int start, finish;
// 
//  // Constructor
//  public Activity(int start, int finish)
//  {
//    this.start = start;
//    this.finish = finish;
//  }
//}
// 
//// class to define user defined comparator
//class Compare
//{
// 
//  // A utility function that is used for sorting
//  // activities according to finish time
//  static void compare(Activity arr[], int n)
//  {
//    Arrays.sort(arr, new Comparator<Activity>()
//                {
//                  @Override
//                  public int compare(Activity s1, Activity s2)
//                  {
//                    return s1.finish - s2.finish;
//                  }
//                });
//  }
//}
// 
//// Driver class
//class GFG {
// 
//  // Returns count of the maximum set of activities that
//  // can
//  // be done by a single person, one at a time.
//  static void printMaxActivities(Activity arr[], int n)
//  {
//    // Sort jobs according to finish time
//    Compare obj = new Compare();
//    obj.compare(arr, n);
//    System.out.println(
//      "Following activities are selected :");
// 
//    // The first activity always gets selected
//    int i = 0;
//    System.out.print("(" + arr[i].start + ", "
//                     + arr[i].finish + "), ");
// 
//    // Consider rest of the activities
//    for (int j = 1; j < n; j++)
//    {
// 
//      // If this activity has start time greater than
//      // or equal to the finish time of previously
//      // selected activity, then select it
//      if (arr[j].start >= arr[i].finish)
//      {
//        System.out.print("(" + arr[j].start + ", "
//                         + arr[j].finish + "), ");
//        i = j;
//      }
//    }
//  }
// 
//  // Driver code
//  public static void main(String[] args)
//  {
// 
//    int n = 6;
//    Activity arr[] = new Activity[n];
//    arr[0] = new Activity(5, 9);
//    arr[1] = new Activity(1, 2);
//    arr[2] = new Activity(3, 4);
//    arr[3] = new Activity(0, 6);
//    arr[4] = new Activity(5, 7);
//    arr[5] = new Activity(8, 9);
// 
//    printMaxActivities(arr, n);
//  }
//}
// 
//// This code is contributed by Dharanendra L V.
// 
// 
//
//Output: 
//
// 
//
//Following activities are selected 
//(1, 2), (3, 4), (5, 7), (8, 9),
// 
//
//Time Complexity: It takes O(n log n) time if input activities may not be sorted. It takes O(n) time when it is given that input activities are always sorted.
//Using STL we can solve it as follows: 
//
// 
//
//
//// java program for the above approach
//import java.io.*;
//import java.lang.*;
//import java.util.*;
// 
//class GFG {
// 
//  // Pair class
//  static class Pair {
// 
//    int first;
//    int second;
// 
//    Pair(int first, int second)
//    {
//      this.first = first;
//      this.second = second;
//    }
//  }
// 
//  static void SelectActivities(int s[], int f[])
//  {
// 
//    // Vector to store results.
//    ArrayList<Pair> ans = new ArrayList<>();
// 
//    // Minimum Priority Queue to sort activities in
//    // ascending order of finishing time (f[i]).
//    PriorityQueue<Pair> p = new PriorityQueue<>(
//      (p1, p2) -> p1.first - p2.first);
// 
//    for (int i = 0; i < s.length; i++) {
//      // Pushing elements in priority queue where the
//      // key is f[i]
//      p.add(new Pair(f[i], s[i]));
//    }
// 
//    Pair it = p.poll();
//    int start = it.second;
//    int end = it.first;
//    ans.add(new Pair(start, end));
// 
//    while (!p.isEmpty()) {
//      Pair itr = p.poll();
//      if (itr.second >= end) {
//        start = itr.second;
//        end = itr.first;
//        ans.add(new Pair(start, end));
//      }
//    }
//    System.out.println(
//      "Following Activities should be selected. \n");
// 
//    for (Pair itr : ans) {
//      System.out.println(
//        "Activity started at: " + itr.first
//        + " and ends at  " + itr.second);
//    }
//  }
// 
//  // Driver Code
//  public static void main(String[] args)
//  {
// 
//    int s[] = { 1, 3, 0, 5, 8, 5 };
//    int f[] = { 2, 4, 6, 7, 9, 9 };
// 
//    // Function call
//    SelectActivities(s, f);
//  }
//}
// 
//// This code is contributed by Kingash.
//Output
//Following Activities should be selected. 
//
//Activity started at: 1 and ends at  2
//Activity started at: 3 and ends at  4
//Activity started at: 5 and ends at  7
//Activity started at: 8 and ends at  9
///////////////////////////////////////////////////////////////////////////


