/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Graph;
import java.io.*;  
import java.util.*;  
/**
 *
 * @author Imran
 */
public class Topological_Sort {
    // A Sample Java program to print topological sorting of a Directed Acyclic Graph(DAG)  

// A class named Graph is created that will represent a directed graph using adjacency list representation   
    
    // A private variable named V of the Integer type is created that will be used to represent the number of nodes in the Directed Acyclic Graph  
    private int V;  
    // A private variable named adj of ArrayList type is created that will represent Adjacency List as ArrayList of ArrayList's  
    private ArrayList<ArrayList<Integer> > adj;  
    // A parameterized constructor is written that will be used to initialize the class variables of the Graph class  
    Topological_Sort(int v)  
    {  
        V = v;  
        adj = new ArrayList<ArrayList<Integer> >(v);  
        for (int i = 0; i < v; ++i)  
            adj.add(new ArrayList<Integer> ());  
    }  
    // Function to add an edge into the graph  
    // A Function named addEdge is written that will be used to add a new edge into the Directed Acyclic Graph    
    void addEdge(int v, int w) {   
        // With the use of add() a new edge will be added into the Directed Acyclic Graph  
        adj.get(v).add(w);   
    }  
    // A recursive function used by topologicalSort  
    // A recursive function named topologicalSortUtil is written that will be used to perform the topological sorting on the edges of the Directed Acyclic Graph  
    void topologicalSortUtil(int v, boolean visited[],  
                            Stack<Integer>  stack)  
    {  
        // Mark the current node as visited.  
        visited[v] = true;  
        Integer i;  
        // Recur for all the vertices adjacent  
        // to thisvertex  
        Iterator<Integer> it = adj.get(v).iterator();  
        while (it.hasNext()) {  
            i = it.next();  
            if (!visited[i])  
                topologicalSortUtil(i, visited, stack);  
        }  
        // Push current vertex to stack  
        // which stores result  
        stack.push(new Integer(v));  
    }  
    // The function to do Topological Sort.  
    // It uses recursive topologicalSortUtil()  
    // A Function named topologicalSort() is written that will be used to call the recursive function named topologicalSortUtil to sort the edges of the Directed Acyclic Graph   
    void topologicalSort()  
    {  
        Stack<Integer> stack = new Stack<Integer>();  
        // Mark all the vertices as not visited  
        boolean visited[] = new boolean[V];  
        for (int i = 0; i < V; i++)  
            visited[i] = false;  
        // Call the recursive helper  
        // function to store  
        // Topological Sort starting  
        // from all vertices one by one  
        for (int i = 0; i < V; i++)  
            if (visited[i] == false)  
                topologicalSortUtil(i, visited, stack);  
        // Print contents of stack  
        while (stack.empty() == false)  
            System.out.print(stack.pop() + " ");  
    }  
    // main function is written to call all the functionalities functions written above  
    public static void main(String args[])  
    {  
        // Now, let us create a graph, and for that, we will create the edges of the Directed Acyclic Graph   
        // A Directed Acyclic Graph with six nodes is created for that an Object of the graph node is created by calling the constructor of the graph class  
        Topological_Sort g = new Topological_Sort(26);  
        Scanner scan = new Scanner(System.in);  
        char ch;  
       /*  Perform list operations  */  
        do  
            {  
                System.out.println("Please Choose one of the Operations::");  
                System.out.println("1. To create a Directed Acyclic Graph (DAG) for topological sort.");  
                System.out.println("2. To print the result of the topological sort.");  
                int choice = scan.nextInt();  
                switch (choice)  
                    {  
                    case 1 :  
                        // A edge starting from vertex 25 and terminating at the vertex 10  is created by calling the addEdge() with passing these starting and terminating vertex to this function   
                        g.addEdge(25, 10);  
                        // A edge starting from vertex 25 and terminating at the vertex 0 is created by calling the addEdge() with passing these starting and terminating vertex to this function  
                        g.addEdge(25, 0);  
                        // A edge starting from vertex 20 and terminating at the vertex 0 is created by calling the addEdge() with passing these starting and terminating vertex to this function  
                        g.addEdge(20, 0);  
                        // A edge starting from vertex 20 and terminating at the vertex 5 is created by calling the addEdge() with passing these starting and terminating vertex to this function  
                        g.addEdge(20, 5);  
                        // A edge starting from vertex 10 and terminating at the vertex 15 is created by calling the addEdge() with passing these starting and terminating vertex to this function  
                        g.addEdge(10, 15);  
                        // A edge starting from vertex 15 and terminating at the vertex 5 is created by calling the addEdge() with passing these starting and terminating vertex to this function  
                        g.addEdge(15, 5);  
                        break;  
                    case 2 :  
                        System.out.println("The result after topological sort of the Directed Acyclic Graph");  
                        g.topologicalSort();                  
                        break;  
                    default :  
                        System.out.println("Wrong Entry\n ");  
                        break;  
                    }  
                System.out.println("\nDo you want to continue (Type y or n)\n");  
                ch = scan.next().charAt(0);  
            }  
        while (ch == 'Y'|| ch == 'y');        
    }  
}  

