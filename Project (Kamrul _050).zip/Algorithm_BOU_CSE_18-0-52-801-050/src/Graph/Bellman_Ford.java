package Graph;
import java.util.*;
import java.lang.*;
import java.io.*;

// A class to represent a connected, directed and weighted graph
class Graph {
	// A class to represent a weighted edge in graph
	class Edge {
		int src, dest, weight;
		Edge()
		{
			src = dest = weight = 0;
		}
	};

	int V, E;
	Edge edge[];

	// Creates a graph with V vertices and E edges
	Graph(int v, int e)
	{
		V = v;
		E = e;
		edge = new Edge[e];
		for (int i = 0; i < e; ++i)
			edge[i] = new Edge();
	}

	// The main function that finds shortest distances from src
	// to all other vertices using Bellman-Ford algorithm. The
	// function also detects negative weight cycle
	void BellmanFord(Graph graph, int src)
	{
		int V = graph.V, E = graph.E;
		int dist[] = new int[V];

		// Step 1: Initialize distances from src to all other
		// vertices as INFINITE
		for (int i = 0; i < V; ++i)
			dist[i] = Integer.MAX_VALUE;
		dist[src] = 0;

		// Step 2: Relax all edges |V| - 1 times. A simple
		// shortest path from src to any other vertex can
		// have at-most |V| - 1 edges
		for (int i = 1; i < V; ++i) {
			for (int j = 0; j < E; ++j) {
				int u = graph.edge[j].src;
				int v = graph.edge[j].dest;
				int weight = graph.edge[j].weight;
				if (dist[u] != Integer.MAX_VALUE && dist[u] + weight < dist[v])
					dist[v] = dist[u] + weight;
			}
		}

		// Step 3: check for negative-weight cycles. The above
		// step guarantees shortest distances if graph doesn't
		// contain negative weight cycle. If we get a shorter
		// path, then there is a cycle.
		for (int j = 0; j < E; ++j) {
			int u = graph.edge[j].src;
			int v = graph.edge[j].dest;
			int weight = graph.edge[j].weight;
			if (dist[u] != Integer.MAX_VALUE && dist[u] + weight < dist[v]) {
				System.out.println("Graph contains negative weight cycle");
				return;
			}
		}
		printArr(dist, V);
	}

	// A utility function used to print the solution
	void printArr(int dist[], int V)
	{
		System.out.println("Vertex Distance from Source");
		for (int i = 0; i < V; ++i)
			System.out.println(i + "\t\t" + dist[i]);
	}

	// Driver method to test above function
	public static void main(String[] args)
	{
		int V = 5; // Number of vertices in graph
		int E = 8; // Number of edges in graph

		Graph graph = new Graph(V, E);

		// add edge 0-1 (or A-B in above figure)
		graph.edge[0].src = 0;
		graph.edge[0].dest = 1;
		graph.edge[0].weight = -1;

		// add edge 0-2 (or A-C in above figure)
		graph.edge[1].src = 0;
		graph.edge[1].dest = 2;
		graph.edge[1].weight = 4;

		// add edge 1-2 (or B-C in above figure)
		graph.edge[2].src = 1;
		graph.edge[2].dest = 2;
		graph.edge[2].weight = 3;

		// add edge 1-3 (or B-D in above figure)
		graph.edge[3].src = 1;
		graph.edge[3].dest = 3;
		graph.edge[3].weight = 2;

		// add edge 1-4 (or B-E in above figure)
		graph.edge[4].src = 1;
		graph.edge[4].dest = 4;
		graph.edge[4].weight = 2;

		// add edge 3-2 (or D-C in above figure)
		graph.edge[5].src = 3;
		graph.edge[5].dest = 2;
		graph.edge[5].weight = 5;

		// add edge 3-1 (or D-B in above figure)
		graph.edge[6].src = 3;
		graph.edge[6].dest = 1;
		graph.edge[6].weight = 1;

		// add edge 4-3 (or E-D in above figure)
		graph.edge[7].src = 4;
		graph.edge[7].dest = 3;
		graph.edge[7].weight = -3;

		graph.BellmanFord(graph, 0);
	}
}







// Contributed by Aakash Hasija


//package Graph;
//
//import java.util.ArrayList;
//import java.util.List;
//
//class Bellman_Ford {
////vertices of the graph  
//
//    private int V;
////edges in the graph  
//    private List<Edge> edges;
////creating a constructor of the Graph class and generating getters and setters  
//
//    public Bellman_Ford(int v) {
//        V = v;
//        edges = new ArrayList<Edge>();
//    }
//
//    public int getV() {
//        return V;
//    }
//
//    public void setV(int v) {
//        V = v;
//    }
//
//    public List<Edge> getEdges() {
//        return edges;
//    }
//
//    public void setEdges(List<Edge> edges) {
//        this.edges = edges;
//    }
//
//    public void addEdge(int u, int v, int w) {
//        Edge e = new Edge(u, v, w);
//        edges.add(e);
//    }
//}
//
//class Edge {
////it is the source vertex      
//
//    private int u;
////it is the destination vertex  
//    private int v;
////it denotes the weight on edge  
//    private int w;
////generating getters and setters  
//
//    public int getU() {
//        return u;
//    }
//
//    public void setU(int u) {
//        this.u = u;
//    }
//
//    public int getV() {
//        return v;
//    }
//
//    public void setV(int v) {
//        this.v = v;
//    }
//
//    public int getW() {
//        return w;
//    }
//
//    public void setW(int w) {
//        this.w = w;
//    }
////creating constructor of the Edge class  
//
//    public Edge(int u, int v, int w) {
//        this.u = u;
//        this.v = v;
//        this.w = w;
//    }
//}
//
//public class BellmanFordImplementation {
//
//    public static void main(String args[]) {
//        Bellman_Ford g = createGraph();
//        int distance[] = new int[g.getV()];
//        boolean hasNegativeCycle = getShortestPaths(g, 1, distance);
//        if (!hasNegativeCycle) {
//            System.out.println("Vertex \t: Distance");
//            for (int i = 1; i < distance.length; i++) {
//                System.out.println("\t" + i + " " + "\t\t" + (distance[i] == Integer.MAX_VALUE ? "-" : distance[i]));
//            }
//        } else {
//            System.out.println("Negative cycle exists in the graph, no solution found!!!");
//        }
//    }
//
//    private static Bellman_Ford createGraph() {
//        int v = 7;
////creating a graph having 7 vertices  
//        Bellman_Ford g = new Bellman_Ford(v);
////adding edges to the graph  
//        g.addEdge(1, 2, 4);
//        g.addEdge(1, 4, 9);
//        g.addEdge(2, 3, -1);
//        g.addEdge(3, 6, 3);
//        g.addEdge(4, 3, 2);
//        g.addEdge(4, 5, -5);
//        g.addEdge(5, 6, 0);
////returns graph  
//        return g;
//    }
////Bellman-Ford logic  
//
//    public static boolean getShortestPaths(Bellman_Ford g, int source, int[] distance) {
//        int V = g.getV();
////initializing distances from source to other vertices  
//        for (int i = 1; i < V; i++) {
//            distance[i] = Integer.MAX_VALUE;
//        }
////source vertex initialize to 0  
//        distance[source] = 0;
////relaxing edges  
//        for (int i = 1; i < V; i++) {
////iterate over edges      
//            for (Edge e : g.getEdges()) {
//                int u = e.getU(), v = e.getV(), w = e.getW();
//                if (distance[u] != Integer.MAX_VALUE && distance[v] > distance[u] + w) {
////calculates distance      
//                    distance[v] = distance[u] + w;
//                }
//            }
//        }
////checks if there exist negative cycles in graph G  
//        for (Edge e : g.getEdges()) {
//            int u = e.getU(), v = e.getV(), w = e.getW();
//            if (distance[u] != Integer.MAX_VALUE && distance[v] > distance[u] + w) {
//                return true;
//            }
//        }
//        return false;
//    }
//}
